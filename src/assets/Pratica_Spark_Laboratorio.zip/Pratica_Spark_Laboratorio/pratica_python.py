import csv
from collections import defaultdict
from decimal import Decimal, InvalidOperation
from pathlib import Path


ENTRADA = Path(__file__).resolve().parent / "dados" / "vendas.csv"


def valor_decimal(campo):
    try:
        valor = Decimal((campo or "").strip())
    except InvalidOperation:
        return None
    return valor if valor.is_finite() else None


def resumir_parte(linhas):
    rejeitadas = []
    totais = defaultdict(lambda: [0, 0, Decimal("0.00")])
    for linha in linhas:
        categoria = (linha["categoria"] or "").strip()
        try:
            quantidade = int(linha["quantidade"] or "")
        except ValueError:
            quantidade = 0
        preco = valor_decimal(linha["preco_unitario"])
        if not categoria or quantidade <= 0 or preco is None or preco <= 0:
            rejeitadas.append(linha)
            continue

        total = totais[categoria]
        total[0] += 1
        total[1] += quantidade
        total[2] += quantidade * preco

    return rejeitadas, totais


def moeda(valor):
    return "R$ " + f"{valor:,.2f}".replace(",", "_").replace(".", ",").replace("_", ".")


def main():
    with ENTRADA.open(encoding="utf-8-sig", newline="") as arquivo:
        linhas = list(csv.DictReader(arquivo))

    corte = len(linhas) // 2
    partes = [linhas[:corte], linhas[corte:]]
    rejeitadas = []
    resumo = defaultdict(lambda: [0, 0, Decimal("0.00")])

    print("Simulação didática em Python")
    print("\n1. Registros por partição")
    for numero, parte in enumerate(partes):
        print(f"Partição {numero}: {len(parte)} registros")
        rejeitadas_parte, parcial = resumir_parte(parte)
        rejeitadas.extend(rejeitadas_parte)
        for categoria, (vendas, unidades, faturamento) in parcial.items():
            total = resumo[categoria]
            total[0] += vendas
            total[1] += unidades
            total[2] += faturamento

    print("\n2. Registros descartados pelo filtro")
    for linha in rejeitadas:
        preco = linha["preco_unitario"] or "vazio"
        print(f'{linha["categoria"]} | {linha["produto"]} | quantidade {linha["quantidade"]} | preço {preco}')

    print("\n3. Faturamento por categoria")
    print(f'{"Categoria":<13} {"Vendas":>6} {"Unidades":>8} {"Faturamento":>13}')
    for categoria, (vendas, unidades, faturamento) in sorted(
        resumo.items(), key=lambda item: (-item[1][2], item[0])
    ):
        print(f"{categoria:<13} {vendas:>6} {unidades:>8} {moeda(faturamento):>13}")
    faturamento_geral = sum(total[2] for total in resumo.values())
    print(f"\nFaturamento geral: {moeda(faturamento_geral)}")


if __name__ == "__main__":
    main()
