# Apache Spark na prática

## Apresentação com o PDF

Abra `Pratica_Spark_Para_Apresentar.pdf` no leitor de PDF do computador. A primeira página mostra as partições. Na segunda, explique o filtro e faça a pergunta à turma. Avance para a terceira página para revelar a resposta e comparar os resultados do Spark.

## Apresentação offline no navegador

Baixe e abra `Pratica_Spark_Offline.html` no Chrome, Edge ou Firefox. O HTML contém o código e os nove registros. Para apresentar em um computador da universidade, leve esse arquivo já baixado.

1. Clique em **1. Partições** e mostre as duas partes dos dados. Cada parte pode ser processada por uma tarefa.
2. Clique em **2. Filtro**. A caneca tem quantidade zero e o lápis está sem preço.
3. Clique em **3. Faturamento**. Os valores de cada parte são combinados por categoria. Papelaria fatura R$ 125,00 e a loja fatura R$ 835,00.
4. Pergunte quanto a loja faturaria se cada um dos dois lápis custasse R$ 5,00. Clique em **Preencher com R$ 5,00**. Mostre o aumento de R$ 10,00 em Papelaria e no total.
5. Use **Restaurar dados originais** para começar novamente.

A página faz uma simulação didática. A execução do Apache Spark está em `pratica_spark.py`. O arquivo `Resultados_Spark.txt` registra os quadros obtidos nos testes com Spark.

## Simulação com apenas Python

Na pasta extraída, execute com Python 3.8 ou superior. O script usa a biblioteca padrão do Python.

```powershell
python pratica_python.py
```

Para repetir a comparação, abra `dados/vendas.csv` em um editor de texto e troque a última linha de `Papelaria,Lápis,2,` para `Papelaria,Lápis,2,5.00`. Salve em UTF-8 e execute novamente. O ponto separa os decimais no CSV.

## Execução real com Apache Spark

A versão fixada é **PySpark 3.5.9**. Use **JDK 11 ou JDK 8 a partir da atualização 8u371**, com Python 3.8 ou superior. Os testes deste pacote usaram Python 3.12 no Linux, com JDK 8u512 e JDK 11.0.33.

No PowerShell, abra a pasta extraída e confira o Java e o Python.

```powershell
java -version
python --version
```

Se for necessário selecionar um JDK 8 ou 11 que já está instalado, substitua o caminho abaixo pela pasta dele. A configuração vale para essa janela do PowerShell.

```powershell
$env:JAVA_HOME = 'C:\caminho\para\jdk-11'
$env:Path = "$env:JAVA_HOME\bin;$env:Path"
java -version
```

Com acesso à instalação de dependências, crie o ambiente virtual e execute. A primeira instalação baixa o PySpark.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-spark.txt
.\.venv\Scripts\python.exe pratica_spark.py
```

No Linux, use `python3 -m venv .venv` e troque `.\.venv\Scripts\python.exe` por `.venv/bin/python`. Para o segundo cenário, use a mesma alteração da linha do lápis no CSV.

## Resultados para conferir

| Faturamento | Dados originais | Lápis a R$ 5,00 |
|---|---:|---:|
| Papelaria | R$ 125,00 | R$ 135,00 |
| Geral | R$ 835,00 | R$ 845,00 |

- [Versões de Java e Python para Spark 3.5.9](https://spark.apache.org/docs/3.5.9/)
- [Instalação do PySpark 3.5.9](https://spark.apache.org/docs/3.5.9/api/python/getting_started/install.html)
