from pathlib import Path

from pyspark.sql import SparkSession
from pyspark.sql import functions as F


ENTRADA = Path(__file__).resolve().parent / "dados" / "vendas.csv"
ESQUEMA = (
    "categoria STRING, produto STRING, "
    "quantidade INT, preco_unitario DECIMAL(12,2)"
)


def main():
    spark = (
        SparkSession.builder.appName("PraticaSparkVendas")
        .master("local[2]")
        .config("spark.driver.bindAddress", "127.0.0.1")
        .config("spark.driver.host", "127.0.0.1")
        .config("spark.sql.shuffle.partitions", 2)
        .config("spark.ui.showConsoleProgress", "false")
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel("WARN")

    try:
        vendas = (
            spark.read.schema(ESQUEMA)
            .options(
                header=True,
                enforceSchema=False,
                ignoreLeadingWhiteSpace=True,
                ignoreTrailingWhiteSpace=True,
            )
            .csv(ENTRADA.as_posix())
            .repartition(2)
        )

        print("\n1. Registros por partição", flush=True)
        (
            vendas.select(F.spark_partition_id().alias("particao"))
            .groupBy("particao")
            .agg(F.count("*").alias("registros"))
            .orderBy("particao")
            .show()
        )

        # Um campo vazio gera nulo. Nesse caso, a regra de validade é falsa.
        venda_valida = F.coalesce(
            (F.col("categoria") != "")
            & (F.col("quantidade") > 0)
            & (F.col("preco_unitario") > 0),
            F.lit(False),
        )
        print("\n2. Registros descartados pelo filtro", flush=True)
        vendas.filter(~venda_valida).orderBy("categoria", "produto").show(truncate=False)

        resumo = (
            vendas.filter(venda_valida)
            .withColumn(
                "valor_venda", F.col("quantidade") * F.col("preco_unitario")
            )
            .groupBy("categoria")
            .agg(
                F.count("*").alias("vendas"),
                F.sum("quantidade").alias("unidades"),
                F.sum("valor_venda").alias("faturamento"),
            )
            .orderBy(F.desc("faturamento"), "categoria")
        )

        print("\n3. Faturamento por categoria", flush=True)
        print("filter, withColumn e groupBy definem o plano do resumo.", flush=True)
        print("A ação show() solicita o resultado e exibe a tabela.", flush=True)
        resumo.show(truncate=False)
    finally:
        spark.stop()


if __name__ == "__main__":
    main()
